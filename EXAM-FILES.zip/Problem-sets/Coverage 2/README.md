# Problem set 2

The statements of these problem sets are in the files

- [Problem set 2.1](./Queue%201%20.py)
- [Problem set 2.2](./Node%202%20.py)
  